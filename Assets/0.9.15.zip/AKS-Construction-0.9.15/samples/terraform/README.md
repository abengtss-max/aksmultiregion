# Terraform Samples

Placeholder for samples of using AKSC within a wider terraform deployment